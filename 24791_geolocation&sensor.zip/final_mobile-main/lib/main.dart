import 'package:flutter/material.dart';
import 'package:declan_final/app.dart'; // Ensure this is the correct path to your app's entry point

void main() {
  runApp(SmartHomeApp()); // Replace with your actual app widget class
}
