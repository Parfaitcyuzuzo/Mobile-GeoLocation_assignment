class SensorData {
  final double x;
  final double y;
  final double z;

  SensorData(this.x, this.y, this.z);
}
