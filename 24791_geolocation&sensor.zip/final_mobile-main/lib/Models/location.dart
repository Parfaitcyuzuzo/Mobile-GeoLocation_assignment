class LocationData {
  final double latitude;
  final double longitude;

  LocationData(this.latitude, this.longitude);
}
